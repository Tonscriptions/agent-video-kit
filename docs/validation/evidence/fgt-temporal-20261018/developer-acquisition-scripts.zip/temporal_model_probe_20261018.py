from __future__ import annotations
import base64, datetime, hashlib, json, pathlib, urllib.request, urllib.error

ROOT = pathlib.Path(__file__).resolve().parent / 'temporal-model-audit-20261018'
ROOT.mkdir(exist_ok=True)

def fetch(url, target):
    request = urllib.request.Request(url, headers={'User-Agent': 'agent-video-kit-source-audit', 'Accept': 'application/vnd.github+json'})
    if target.is_file():
        data = target.read_bytes()
        return data, {'url': url, 'status': 200, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'existing_saved_response': True}
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            data = response.read(16 * 1024 * 1024 + 1)
            if len(data) > 16 * 1024 * 1024:
                raise RuntimeError('response exceeds audit limit')
            record = {'url': url, 'status': response.status, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    except urllib.error.HTTPError as error:
        data = error.read(16384)
        record = {'url': url, 'status': error.code, 'bytes': len(data), 'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return data, record

records = []
for slug in ('hitachinsk/FGT', 'vt-vl-lab/FGVC', 'ruiliu-ai/FuseFormer', 'sczhou/ProPainter', 'Kunbyte-AI/ROSE'):
    directory = ROOT / slug.replace('/', '__')
    raw, meta_rec = fetch('https://api.github.com/repos/' + slug, directory / 'repository.json')
    if meta_rec['status'] != 200:
        records.append({'repository': slug, 'metadata': meta_rec})
        continue
    meta = json.loads(raw)
    branch = meta['default_branch']
    commit_raw, commit_rec = fetch('https://api.github.com/repos/' + slug + '/commits/' + branch, directory / 'commit.json')
    commit = json.loads(commit_raw)['sha']
    tree_raw, tree_rec = fetch('https://api.github.com/repos/' + slug + '/git/trees/' + commit + '?recursive=1', directory / 'tree.json')
    tree = json.loads(tree_raw)['tree']
    documents = []
    for entry in tree:
        name = entry['path']
        if entry['type'] == 'blob' and ('license' in name.lower() or name.lower() in {'readme.md', 'requirements.txt'}):
            raw_blob, rec = fetch('https://api.github.com/repos/' + slug + '/git/blobs/' + entry['sha'], directory / (name.replace('/', '__') + '.blob.json'))
            content = json.loads(raw_blob)
            data = base64.b64decode(content['content'], validate=False)
            document = directory / name
            document.parent.mkdir(parents=True, exist_ok=True)
            document.write_bytes(data)
            rec.update(path=name, decoded_bytes=len(data), decoded_sha256=hashlib.sha256(data).hexdigest())
            documents.append(rec)
    item = {'repository': slug, 'commit': commit, 'stars_snapshot': meta['stargazers_count'], 'forks_snapshot': meta['forks_count'], 'license_metadata': meta.get('license'), 'metadata': meta_rec, 'commit_record': commit_rec, 'tree_record': tree_rec, 'documents': documents}
    records.append(item)
    print(json.dumps({'repository': slug, 'commit': commit, 'stars': item['stars_snapshot'], 'license': (meta.get('license') or {}).get('spdx_id'), 'files': len(tree), 'license_files': [e['path'] for e in tree if 'license' in e['path'].lower()], 'model_files': [e['path'] for e in tree if any(part in e['path'].lower() for part in ('pretrain', 'checkpoint', 'download', 'weight'))][:18]}, ensure_ascii=False), flush=True)
    (ROOT / 'verification.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
