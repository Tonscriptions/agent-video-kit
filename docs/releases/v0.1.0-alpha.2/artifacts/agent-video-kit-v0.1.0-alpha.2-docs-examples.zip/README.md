# 100 look presets / 100 风格预设

[Usage](docs/releases/v0.1.0-alpha.2/USAGE.md) · [100 numbered examples](docs/local/LOOK_PRESETS.md) · [Verification](docs/validation/LOOK_PRESETS_20261024.md)

Install the separate application ZIP first. This archive contains actual synthetic inputs, 100 preview PNGs, 100 rendered videos, GIFs, a project package and complete command responses. Historical documentation/source snapshots referenced by provenance remain in the full Git repository.
