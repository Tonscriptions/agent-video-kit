from pathlib import Path
import hashlib,json,sys,time
ROOT=Path('E:/dev/sandbox/AI广告剪辑')
sys.path[:0]=[str(ROOT/'product/src'),str(Path(__file__).resolve().parent),str(ROOT/'research/temporal-background'),str(ROOT/'scripts')]
from ai_ad_editor.runtime import configure_local_runtime
configure_local_runtime()
from ai_ad_editor.rvm_worker import install_network_guard
EVENTS=[];install_network_guard(EVENTS)
import coherent_reference as candidate
import cv2,numpy as np
from probe_coherent_reference import stats
cv2.setNumThreads(4);cv2.ocl.setUseOpenCL(False)
before=ROOT/'product/.runtime/coherent-reference-development-20261018'
record={'candidate_sha256':'sha256:'+hashlib.sha256(Path(candidate.__file__).read_bytes()).hexdigest(),'stage':'old-synthetic-diagnostics-only','fresh_holdouts_not_read':True,'cases':{}}
for name in ('translation','two_surfaces'):
    path=before/(name+'.npz')
    with np.load(path,allow_pickle=False) as j:
        source,forbidden,selected,fallback,truth,baseline=[j[k] for k in ('source','forbidden','selected','fallback','truth','baseline')]
        regions={k[:-7]:j[k] for k in j.files if k.endswith('_region') and j[k].any()}
    cv2.setRNGSeed(17018);began=time.monotonic()
    output,used,report=candidate.run(source,forbidden,selected,fallback,min_donors=2 if name=='translation' else 3)
    metrics={k:{'before':stats(baseline,truth,m),'after':stats(output,truth,m)} for k,m in {'combined':selected,**regions}.items()}
    record['cases'][name]={'metrics':metrics,'seconds':time.monotonic()-began,'changed_rgb_pixels':int(np.any(output[:,:,:,:3]!=baseline[:,:,:,:3],axis=3).sum()),'coherent_label_changes_accepted':sum(f.get('coherent_changed_selected_pixels',0) for f in report['per_frame'])}
    print(json.dumps({'case':name,**record['cases'][name]}),flush=True)
record['network_guard_events']=EVENTS
(Path(__file__).parent/'quick-comparison.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
