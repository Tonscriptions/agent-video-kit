from __future__ import annotations
import datetime, hashlib, json, pathlib, urllib.request, zipfile
ROOT = pathlib.Path(__file__).resolve().parent / 'temporal-model-audit-20261018'
for name in ('Kunbyte-AI__ROSE', 'hitachinsk__FGT'):
    root = ROOT / name
    meta = json.loads((root / 'repository.json').read_text())
    commit = json.loads((root / 'commit.json').read_text())['sha']
    archive = root / (commit + '.zip')
    url = 'https://codeload.github.com/' + meta['full_name'] + '/zip/' + commit
    if not archive.is_file():
        request = urllib.request.Request(url, headers={'User-Agent': 'agent-video-kit-source-audit'})
        with urllib.request.urlopen(request, timeout=45) as response, archive.with_suffix('.part').open('wb') as output:
            count = 0
            while block := response.read(1024 * 1024):
                count += len(block)
                if count > 300 * 1024 * 1024: raise RuntimeError('audit archive limit')
                output.write(block)
        archive.with_suffix('.part').replace(archive)
    selected = []
    with zipfile.ZipFile(archive) as bundle:
        for entry in bundle.infolist():
            parts = pathlib.PurePosixPath(entry.filename).parts[1:]
            if not parts or '..' in parts or entry.is_dir(): continue
            relative = pathlib.PurePosixPath(*parts)
            if not (relative.suffix in {'.py', '.yaml', '.yml', '.txt'} or relative.name == 'LICENSE'): continue
            if entry.file_size > 4 * 1024 * 1024: raise RuntimeError('individual audit source limit')
            data = bundle.read(entry)
            target = root / 'source' / pathlib.Path(*parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            selected.append({'path': relative.as_posix(), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    record = {'repository': meta['full_name'], 'commit': commit, 'url': url, 'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'archive_bytes': archive.stat().st_size, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'selected': selected, 'research_only': True, 'redistribution_license_audit_complete': False}
    (root / 'acquisition.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k,v in record.items() if k != 'selected'}), flush=True)
