import argparse
import csv
import json
import os
import sys
from typing import Dict

from utils.cli_protocol import emit_result, make_result
from utils.config import CONFIG
from utils.errors import InfraError
from utils.formatters import find_draft_content_path
from utils.logging_utils import setup_logger

logger = setup_logger("build_cloud_music_library")


def _get_default_projects_root() -> str:
    """跨平台探测剪映草稿目录"""
    if sys.platform == "darwin":
        home = os.path.expanduser("~")
        candidates = [
            os.path.join(home, "Movies", "JianyingPro Drafts"),
            os.path.join(
                home, "Movies", "JianyingPro", "User Data", "Projects", "com.lveditor.draft"
            ),
            os.path.join(
                home,
                "Library",
                "Containers",
                "com.lemon.lvpro",
                "Data",
                "Library",
                "Application Support",
                "JianyingPro",
                "User Data",
                "Projects",
                "com.lveditor.draft",
            ),
        ]
    else:
        local_app_data = os.getenv("LOCALAPPDATA", "")
        candidates = (
            [
                os.path.join(
                    local_app_data, "JianyingPro", "User Data", "Projects", "com.lveditor.draft"
                ),
                os.path.join(
                    local_app_data, "CapCut", "User Data", "Projects", "com.lveditor.draft"
                ),
            ]
            if local_app_data
            else []
        )

    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0] if candidates else ""


PROJECTS_ROOT = CONFIG.projects_root_override or _get_default_projects_root()

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_CSV = os.path.join(SKILL_ROOT, "data", "cloud_music_library.csv")
SFX_CSV = os.path.join(SKILL_ROOT, "data", "cloud_sound_effects.csv")


def load_existing_csv(path: str, id_key: str) -> Dict[str, dict]:
    library: Dict[str, dict] = {}
    if not os.path.exists(path):
        return library
    try:
        with open(path, "r", encoding="utf-8", newline="") as f:
            lines = [line for line in f if not line.startswith("#")]
        if not lines:
            return library
        reader = csv.DictReader(lines)
        for row in reader:
            m_id = row.get(id_key, "")
            if not m_id:
                continue
            cats = set((row.get("categories") or "").split("|")) if row.get("categories") else set()
            library[m_id] = {
                id_key: m_id,
                "title": row.get("title", "Unknown"),
                "duration_s": float(row.get("duration_s") or 0.0),
                "categories": {c for c in cats if c},
            }
    except Exception as e:
        logger.warning("Reading existing CSV failed (%s): %s", path, e)
    return library


def save_to_csv(path: str, library: Dict[str, dict], id_key: str, title_prefix: str) -> None:
    sorted_ids = sorted(library.keys(), key=lambda x: library[x]["title"])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write(f"# JianYing Cloud {title_prefix} Library\n")
        f.write(f"# AI Guidance: Use '{id_key}' to reference. Sync if not available.\n")
        f.write("# Schema: identifier,title,duration_s,categories\n")

        writer = csv.DictWriter(f, fieldnames=[id_key, "title", "duration_s", "categories"])
        writer.writeheader()
        for m_id in sorted_ids:
            info = library[m_id]
            writer.writerow(
                {
                    id_key: m_id,
                    "title": info["title"],
                    "duration_s": info["duration_s"],
                    "categories": "|".join(sorted(list(info["categories"]))),
                }
            )


def build_libraries(
    projects_root: str = PROJECTS_ROOT,
    music_csv: str = MUSIC_CSV,
    sfx_csv: str = SFX_CSV,
    dry_run: bool = False,
) -> tuple[int, dict]:
    logger.info("Scanning Jianying projects for cloud assets...")

    if not projects_root or not os.path.exists(projects_root):
        err = InfraError(f"Projects root not found: {projects_root or '<LOCALAPPDATA missing>'}")
        logger.error(str(err))
        return 1, make_result(
            False, "projects_root_missing", str(err), {"projects_root": projects_root}
        )

    music_lib = load_existing_csv(music_csv, "music_id")
    sfx_lib = load_existing_csv(sfx_csv, "effect_id")
    skipped_projects = 0

    for project_name in os.listdir(projects_root):
        project_path = os.path.join(projects_root, project_name)
        if not os.path.isdir(project_path):
            continue
        content_path = find_draft_content_path(project_path)
        if not content_path:
            continue

        try:
            with open(content_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            audios = data.get("materials", {}).get("audios", [])
            for audio in audios:
                m_type = audio.get("type")
                title = audio.get("name", "Unknown")
                duration_us = int(audio.get("duration", 0) or 0)
                category = audio.get("category_name")

                if m_type == "music":
                    m_id = str(audio.get("music_id") or audio.get("id") or "")
                    if not m_id:
                        continue
                    if m_id not in music_lib:
                        music_lib[m_id] = {
                            "music_id": m_id,
                            "title": title,
                            "duration_s": round(duration_us / 1_000_000, 2),
                            "categories": set(),
                        }
                    if category:
                        music_lib[m_id]["categories"].add(category)
                elif m_type == "sound":
                    e_id = str(audio.get("effect_id") or "")
                    if not e_id:
                        continue
                    if e_id not in sfx_lib:
                        sfx_lib[e_id] = {
                            "effect_id": e_id,
                            "title": title,
                            "duration_s": round(duration_us / 1_000_000, 2),
                            "categories": set(),
                        }
                    if category:
                        sfx_lib[e_id]["categories"].add(category)
        except Exception as e:
            logger.warning("Skipping project '%s': %s", project_name, e)
            skipped_projects += 1

    if not dry_run:
        save_to_csv(music_csv, music_lib, "music_id", "Music")
        save_to_csv(sfx_csv, sfx_lib, "effect_id", "Sound Effects")
    logger.info("Success. Music=%d, SFX=%d", len(music_lib), len(sfx_lib))
    return 0, make_result(
        True,
        "ok",
        "",
        {
            "projects_root": projects_root,
            "music_count": len(music_lib),
            "sfx_count": len(sfx_lib),
            "skipped_projects": skipped_projects,
            "dry_run": dry_run,
            "music_csv": music_csv,
            "sfx_csv": sfx_csv,
        },
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build cloud music/sfx library from local drafts")
    parser.add_argument(
        "--projects-root", default=PROJECTS_ROOT, help="JianYing draft projects root"
    )
    parser.add_argument("--music-csv", default=MUSIC_CSV, help="Output music csv path")
    parser.add_argument("--sfx-csv", default=SFX_CSV, help="Output sound effects csv path")
    parser.add_argument("--dry-run", action="store_true", help="Scan only, do not write csv")
    parser.add_argument("--json", action="store_true", help="Output JSON summary")
    args = parser.parse_args()

    exit_code, summary = build_libraries(
        projects_root=args.projects_root,
        music_csv=args.music_csv,
        sfx_csv=args.sfx_csv,
        dry_run=args.dry_run,
    )
    emit_result(summary, args.json)
    raise SystemExit(exit_code)
