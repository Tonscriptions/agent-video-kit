from __future__ import annotations
import datetime, hashlib, json, pathlib, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent/'temporal-model-audit-20261018'
for slug in ('hitachinsk/FGT','Kunbyte/ROSE','alibaba-pai/Wan2.1-Fun-1.3B-InP'):
    directory=ROOT/'models'/slug.replace('/','__');directory.mkdir(parents=True,exist_ok=True)
    attempts=[]
    for endpoint,timeout in (('https://huggingface.co',6),('https://hf-mirror.com',30)):
        url=endpoint+'/api/models/'+slug+'?blobs=true'
        request=urllib.request.Request(url,headers={'User-Agent':'agent-video-kit-source-audit'})
        try:
            with urllib.request.urlopen(request,timeout=timeout) as response:data=response.read(8*1024*1024)
            attempts.append({'url':url,'status':'retrieved'})
            break
        except Exception as error:
            attempts.append({'url':url,'status':'failed','error':str(error)})
    else:
        (directory/'retrieval-failure.json').write_text(json.dumps(attempts,indent=2)+'\n')
        print(json.dumps({'model_id':slug,'attempts':attempts}),flush=True)
        continue
    (directory/'metadata.json').write_bytes(data)
    meta=json.loads(data)
    record={'url':url,'attempts':attempts,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(data).hexdigest(),'revision':meta.get('sha'),'model_id':slug,'license':meta.get('cardData',{}).get('license'),'files':[{'path':f['rfilename'],'bytes':f.get('size'),'lfs':f.get('lfs')} for f in meta.get('siblings',[])]}
    (directory/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
