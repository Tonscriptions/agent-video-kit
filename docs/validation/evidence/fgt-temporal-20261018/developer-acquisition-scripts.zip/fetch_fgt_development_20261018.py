"""Explicit developer acquisition; never imported by product/runtime workers."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime, hashlib, json, pathlib, time, urllib.request, zipfile
ROOT=pathlib.Path(__file__).resolve().parent/'temporal-model-audit-20261018'
meta=json.loads((ROOT/'models/hitachinsk__FGT/metadata.json').read_text())
revision=meta['sha'];destination=ROOT/'fgt-weights';destination.mkdir(exist_ok=True)
names={'README.md','FGT_config.yaml','LAFC_config.yaml','fgt.pth.tar','lafc.pth.tar'}

def get_file(entry):
    name=entry['rfilename'];path=destination/name;expected=(entry.get('lfs') or {}).get('sha256')
    url='https://hf-mirror.com/hitachinsk/FGT/resolve/'+revision+'/'+name+'?download=true'
    started=time.monotonic()
    request=urllib.request.Request(url,headers={'User-Agent':'agent-video-kit-development'})
    if not path.exists():
        with urllib.request.urlopen(request,timeout=45) as response, path.with_suffix(path.suffix+'.part').open('wb') as output:
            received=0;last=time.monotonic()
            while block:=response.read(1024*1024):
                output.write(block);received+=len(block)
                if received>entry['size']:raise RuntimeError('file size exceeds fixed metadata')
                if time.monotonic()-last>20:
                    print(json.dumps({'file':name,'received':received,'expected':entry['size']}),flush=True);last=time.monotonic()
        path.with_suffix(path.suffix+'.part').replace(path)
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if path.stat().st_size!=entry['size'] or expected and actual!=expected:raise RuntimeError('download verification failed: '+name)
    record={'path':name,'sha256':actual,'expected_lfs_sha256_from_mirror_metadata':expected,'bytes':path.stat().st_size,'retrieval_url':url,'seconds':time.monotonic()-started}
    print(json.dumps(record),flush=True)
    return record

records=[]
with ThreadPoolExecutor(max_workers=2) as executor:
    for future in as_completed([executor.submit(get_file,entry) for entry in meta['siblings'] if entry['rfilename'] in names]):records.append(future.result())
upstream=ROOT/'hitachinsk__FGT'
with zipfile.ZipFile(next(upstream.glob('*.zip'))) as archive:
    entry=next(e for e in archive.infolist() if e.filename.endswith('/LAFC/flowCheckPoint/raft-things.pth'))
    data=archive.read(entry);path=destination/'raft-things.pth';path.write_bytes(data)
    records.append({'path':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':'fixed FGT archive LAFC/flowCheckPoint/raft-things.pth'})
record={'model_id':'hitachinsk/FGT','revision':revision,'declared_license':meta.get('cardData',{}).get('license'),'retrieval_mirror':'https://hf-mirror.com','retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':records,'usage':'research-only candidate; no new production adapter, model weights excluded from repository','source':json.loads((upstream/'acquisition.json').read_text())['commit']}
(ROOT/'fgt-model-acquisition.json').write_text(json.dumps(record,indent=2)+'\n')
