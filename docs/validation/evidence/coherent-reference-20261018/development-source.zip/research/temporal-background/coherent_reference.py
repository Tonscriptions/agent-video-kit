"""Observed donor selection with bounded spatial and warped temporal penalties.

Research only. A reconstructed previous frame supplies a cost, never a donor,
and can be wrong. Observed-context scores do not establish hidden geometry.
"""
from __future__ import annotations

import warnings

import cv2
import numpy as np

from camera_motion import estimate_camera
from flow_core import _grid, _inside, _remap, estimate, validate_inputs
from reference_core import _context_error, choose_reference

ALGORITHM = 'observed-donor-spatial-warped-temporal-cost-v1'
SPATIAL_WEIGHT = .08
TEMPORAL_WEIGHT = .06
SWEEPS = 4


def array_bound(frames, height, width):
    return height * width * (224 * frames + 2048)


def _gather(bank, labels):
    height, width = labels.shape
    return bank[labels, np.arange(height)[:, None], np.arange(width)[None, :]]


def refine_labels(bank, unary, allowed, eligible, *, prior=None, prior_valid=None,
                  checkpoint=None):
    """Fixed red/black label refinements; no global-energy optimum is claimed.

    Neighbor labels are compared at the same pixel. Unsupported neighbor labels
    contribute no cost. Every selected label must still pass observed-source,
    distinct-frame and color-consensus admission from the caller.
    """
    if (bank.dtype != np.float32 or bank.ndim != 4 or bank.shape[-1] != 3
            or unary.shape != bank.shape[:3] or allowed.shape != unary.shape
            or allowed.dtype != np.bool_ or eligible.shape != bank.shape[1:3]
            or eligible.dtype != np.bool_ or not np.isfinite(bank[allowed]).all()
            or not np.isfinite(unary[allowed]).all()):
        raise ValueError('COHERENT_LABEL_CONTRACT_INVALID')
    if np.any(eligible & ~allowed.any(axis=0)):
        raise ValueError('COHERENT_LABEL_WITHOUT_DONOR')
    colors = np.nan_to_num(bank, nan=0., posinf=0., neginf=0.)
    cost = np.where(allowed, unary, np.inf).astype(np.float32)
    if (prior is None) != (prior_valid is None):
        raise ValueError('COHERENT_PRIOR_CONTRACT_INVALID')
    if prior is not None:
        if (prior.shape != bank.shape[1:] or prior.dtype != np.float32
                or prior_valid.shape != eligible.shape or prior_valid.dtype != np.bool_
                or not np.isfinite(prior).all()):
            raise ValueError('COHERENT_PRIOR_CONTRACT_INVALID')
        difference = np.minimum(np.mean(np.abs(colors - prior[None]), axis=3), 20.)
        cost += TEMPORAL_WEIGHT * difference * prior_valid[None]
    labels = np.argmin(cost, axis=0)
    y, x = np.indices(eligible.shape)
    changes = []
    for sweep in range(SWEEPS):
        if checkpoint:
            checkpoint('labels', sweep, SWEEPS)
        changed = 0
        for parity in (0, 1):
            value = cost.copy()
            for axis, offset in ((0, -1), (0, 1), (1, -1), (1, 1)):
                neighbor_labels = np.roll(labels, offset, axis=axis)
                support = np.roll(eligible, offset, axis=axis) & eligible
                if axis == 0:
                    support[0 if offset == 1 else -1, :] = False
                else:
                    support[:, 0 if offset == 1 else -1] = False
                neighbor_supported = _gather(allowed[:, :, :, None], neighbor_labels)[:, :, 0]
                support &= neighbor_supported
                neighbor_color = _gather(colors, neighbor_labels)
                penalty = np.minimum(np.mean(np.abs(colors - neighbor_color[None]), axis=3), 40.)
                value += (SPATIAL_WEIGHT / 4) * penalty * support[None]
            proposed = np.argmin(value, axis=0)
            active = eligible & ((x + y) % 2 == parity)
            changed += int(np.count_nonzero(active & (proposed != labels)))
            labels[active] = proposed[active]
        changes.append(changed)
    return labels, {'label_changes_per_sweep': changes,
                    'spatial_weight': SPATIAL_WEIGHT, 'temporal_weight': TEMPORAL_WEIGHT,
                    'sweeps': SWEEPS, 'global_energy_optimum_proven': False}


def temporal_prior(index, source_rgb, blocked, output, contributed, models, base):
    """Warp prior reconstruction, rank geometry on unmodified visible RGB only."""
    height, width = blocked.shape[1:]
    values, valid_masks, own_contexts = [], [], []
    for flows, confidence in models.values():
        key = index, index - 1
        if key not in flows:
            continue
        coordinates = base + flows[key]
        path = confidence[key] & _inside(coordinates, height, width)
        observed = path & (_remap((~blocked[index - 1]).astype(np.float32), coordinates) >= 1.)
        valid = path & (_remap(contributed[index - 1].astype(np.float32), coordinates) >= 1.)
        own_contexts.append((~blocked[index]) & observed)
        valid_masks.append(valid)
        values.append((_remap(source_rgb[index - 1], coordinates),
                       _remap(output[index - 1, :, :, :3].astype(np.float32), coordinates)))
    if not values:
        return np.zeros((height, width, 3), np.float32), np.zeros((height, width), bool)
    common = np.logical_and.reduce(own_contexts)
    common_count = cv2.boxFilter(common.astype(np.float32), -1, (65, 65),
                                normalize=False, borderType=cv2.BORDER_CONSTANT)
    costs, usable = [], []
    for (observed_rgb, _), context, valid in zip(values, own_contexts, valid_masks):
        own_error, own_count = _context_error(source_rgb[index], observed_rgb, context)
        shared_error, _ = _context_error(source_rgb[index], observed_rgb, common)
        costs.append(np.where(common_count >= 64, shared_error, own_error))
        usable.append(valid & (own_count >= 64))
    costs, usable = np.stack(costs), np.stack(usable)
    if len(values) > 1:
        usable &= (common_count >= 64)[None] | (usable.sum(axis=0) == 1)[None]
    usable &= costs <= 12
    costs = np.where(usable, costs, np.inf)
    chosen = np.argmin(costs, axis=0)
    return _gather(np.stack([value[1] for value in values]), chosen), np.isfinite(costs.min(axis=0))


def propagate(source, forbidden, selected, fallback, models, *, min_donors=3,
              max_spread=10., checkpoint=None):
    frames, height, width, _ = source.shape
    base = _grid(height, width)
    blocked = forbidden | selected | (source[:, :, :, 3] < 255)
    rgb = source[:, :, :, :3].astype(np.float32)
    rgb[blocked] = 0
    output, contributed = fallback.copy(), np.zeros(selected.shape, bool)
    reports = []
    for index in range(frames):
        if checkpoint:
            checkpoint('reference', index, frames)
        info = {'frame': index, 'selected': int(selected[index].sum()),
                'contributed': 0, 'donor_frames': [], 'temporal_prior_pixels': 0}
        if not selected[index].any():
            reports.append(info)
            continue
        values, masks, costs, donors = [], [], [], []
        for direction in (-1, 1):
            states = {name: (base.copy(), np.ones((height, width), bool), index) for name in models}
            for donor in range(index + direction, frames if direction > 0 else -1, direction):
                candidates = []
                for name, (flows, confidence) in models.items():
                    if name not in states:
                        continue
                    coordinates, path_ok, previous = states[name]
                    key = previous, donor
                    if key not in flows:
                        del states[name]
                        continue
                    flow, quality = flows[key], confidence.get(key)
                    if (not isinstance(flow, np.ndarray) or flow.dtype != np.float32
                            or flow.shape != (height, width, 2) or not np.isfinite(flow).all()
                            or not isinstance(quality, np.ndarray) or quality.dtype != np.bool_
                            or quality.shape != (height, width)):
                        raise ValueError('COHERENT_MAP_CONTRACT_INVALID')
                    path_ok &= _remap(quality.astype(np.float32), coordinates) >= 1.
                    coordinates += _remap(flow, coordinates)
                    path_ok &= _inside(coordinates, height, width)
                    states[name] = coordinates, path_ok, donor
                    valid = path_ok & (_remap((~blocked[donor]).astype(np.float32), coordinates) >= 1.)
                    candidates.append((name, _remap(rgb[donor], coordinates), valid))
                if not states:
                    break
                best, valid, context_cost, _, _ = choose_reference(rgb[index], candidates, ~blocked[index])
                values.append(best)
                masks.append(valid)
                costs.append(context_cost + .1 * abs(donor - index))
                donors.append(donor)
        if not donors:
            reports.append(info)
            continue
        bank, valid, context_cost = np.stack(values), np.stack(masks), np.stack(costs)
        del values, masks, costs
        bank[~valid] = np.nan
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='All-NaN slice encountered')
            median = np.nanmedian(bank, axis=0)
            deviation = np.nanmax(np.abs(bank - median), axis=3)
        agreeing = valid & (deviation <= max_spread)
        eligible = (agreeing.sum(axis=0) >= min_donors) & selected[index]
        components, labels, stats, _ = cv2.connectedComponentsWithStats(eligible.astype(np.uint8), 8)
        for label in range(1, components):
            if stats[label, cv2.CC_STAT_AREA] < 64:
                eligible[labels == label] = False
        prior, prior_valid = temporal_prior(index, rgb, blocked, output, contributed, models, base)
        prior_valid &= eligible
        choice, label_report = refine_labels(bank, context_cost + .05 * deviation,
            agreeing, eligible, prior=prior, prior_valid=prior_valid, checkpoint=checkpoint)
        best = _gather(bank, choice)
        weight = np.minimum(cv2.distanceTransform(eligible.astype(np.uint8), cv2.DIST_L2, 3) / 3, 1)
        use = eligible & np.isfinite(best).all(axis=2)
        output[index, use, :3] = np.rint(np.clip(
            best[use] * weight[use, None] + fallback[index, use, :3] * (1 - weight[use, None]),
            0, 255)).astype(np.uint8)
        contributed[index] = use
        info.update(contributed=int(use.sum()), donor_frames=donors,
                    temporal_prior_pixels=int(prior_valid.sum()), **label_report)
        reports.append(info)
    return output, contributed, reports


def run(source, forbidden, selected, fallback, *, scene_cuts=(), min_donors=3,
        max_spread=10., budget=1536 * 1024**2, checkpoint=None):
    frames, height, width = validate_inputs(source, forbidden, selected, fallback, budget)
    if (type(min_donors) is not int or not 1 <= min_donors <= 64
            or type(max_spread) not in {int, float} or not np.isfinite(max_spread)
            or not 0 <= max_spread <= 64 or any(type(i) is not int or not 0 < i < frames for i in scene_cuts)
            or len(set(scene_cuts)) != len(scene_cuts) or (checkpoint is not None and not callable(checkpoint))):
        raise ValueError('COHERENT_OPTIONS_INVALID')
    owned = array_bound(frames, height, width)
    if owned > budget:
        raise ValueError('COHERENT_OWNED_ARRAY_BUDGET_EXCEEDED')
    if checkpoint:
        checkpoint('prepare', 0, frames)
    excluded = forbidden | selected
    camera, camera_quality, camera_report = estimate_camera(source, excluded, scene_cuts=scene_cuts, checkpoint=checkpoint)
    dense, dense_quality, dense_report = estimate(source, excluded, scene_cuts=scene_cuts, checkpoint=checkpoint)
    output, used, per_frame = propagate(source, excluded, selected, fallback,
        {'camera': (camera, camera_quality), 'dense': (dense, dense_quality)},
        min_donors=min_donors, max_spread=max_spread, checkpoint=checkpoint)
    if (not np.array_equal(output[~selected], source[~selected])
            or not np.array_equal(output[:, :, :, 3], source[:, :, :, 3])):
        raise ValueError('COHERENT_PRESERVATION_FAILED')
    return output, used, {'algorithm': ALGORITHM, 'frames': frames, 'width': width, 'height': height,
        'scene_cuts': list(scene_cuts), 'min_distinct_donor_frames': min_donors,
        'max_spread': max_spread, 'owned_array_estimate_bytes': owned,
        'budget_scope': 'conservative-owned-array-estimate-excludes-inputs-opencv-internals-total-process-ram',
        'camera_edges': camera_report, 'dense_edges': dense_report, 'per_frame': per_frame,
        'selected_pixels': int(selected.sum()), 'contributed_pixels': int(used.sum()),
        'temporal_prior_is_cost_not_observation': True, 'availability_is_not_accuracy': True,
        'outside_mask_changed_pixels': 0, 'source_alpha_exact': True,
        'hidden_motion_verified': False, 'full_video_temporal_quality_accepted': False,
        'product_integrated': False}
