# Release examples / 发布案例

Actual inputs, rendered outputs and GIFs: docs/assets/release-v0.1.0-alpha.1-r2/.
Commands, complete stdout/stderr and checks: docs/validation/evidence/release-v0.1.0-alpha.1-r2/.
Project package with embedded media: project/field.avk.zip.
Rights Ledger retains original absolute evidence paths. After relocation, use rights update to bind the reviewed provided media/LICENSE.txt equivalent in docs/assets/release-v0.1.0-alpha.1-r2/, then check rights. Cross-machine evidence-path portability was not tested.
Reproducer: scripts/first_release_cases.py --help (existing native installed runtime and host Pillow required).
Source artwork/audio and template are CC0; no models or font binary included.
The archived C03 Float32 example is linked in the full source repository and is not duplicated in this examples ZIP.
See the tagged repository's bilingual README/CASES.md for complete navigation and historical evidence.
