from __future__ import annotations
import importlib, json, os, pathlib, sys, time, traceback
ROOT = pathlib.Path(__file__).resolve().parents[2]
RUNTIME = ROOT / 'product/.runtime'
AUDIT = RUNTIME / 'temporal-model-audit-20261018'
os.environ.update(HF_HOME=str(RUNTIME/'models/huggingface'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1', TOKENIZERS_PARALLELISM='false', TMP=str(RUNTIME/'temp'), TEMP=str(RUNTIME/'temp'), PYTHONDONTWRITEBYTECODE='1')
(RUNTIME/'temp').mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT/'product/src'))
from ai_ad_editor.rvm_worker import install_network_guard
events=[]
install_network_guard(events)
sys.path.insert(0,str(AUDIT/'Kunbyte-AI__ROSE/source'))
record={'network':'disabled', 'blocked_network_events':events, 'research_only':True, 'stages':[]}
started=time.monotonic()
for name in ('torch', 'diffusers', 'transformers', 'rose.models', 'rose.pipeline'):
    try:
        mod=importlib.import_module(name)
        stage={'module':name,'ok':True,'version':getattr(mod,'__version__',None)}
    except Exception as error:
        stage={'module':name,'ok':False,'error':type(error).__name__+': '+str(error),'traceback':traceback.format_exc()}
    record['stages'].append(stage)
    print(json.dumps({k:v for k,v in stage.items() if k!='traceback'}),flush=True)
    if not stage['ok']:break
record['elapsed_seconds']=time.monotonic()-started
(AUDIT/'rose-native-import.json').write_text(json.dumps(record,indent=2)+'\n')
